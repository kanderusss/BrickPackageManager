
"""
Usage: pkg.py <cmd> <user> <repo>

Commands:
    install:
        installs package from github
        example: pkg.py install pallets flask
    exists:
        shows user is package exists
        example:
            pkg.py exists pallets flask         # Yes
            pkg.py exists something1 something2 # No
    uninstall:
        uninstalls package
How to test pkg:
    install:
        type pkg.py install pallets flask
        if it works, then its ok!
    exists:
        type pkg.py exists pallets flask
        if it shows you that it exists, then its ok!
        type pkg.py exists something1 something2
        if it shows you that it not exists, then its ok!
    uninstall:
        type pkg.py install pallets flask
        type pkg.py uninstall pallets flask
        if it works, then its ok!
"""



print("--- Brick package manager ---")



import os
from shutil import rmtree
import io
import requests as req
from zipfile import ZipFile
import sys

sample_url = 'https://github.com/{user}/{repo}/zipball/main'

def install(user, repo):
    path = f"./bricks/{user}/{repo}"
    if os.path.exists(path):
        print(f"Warning: \"{user}/{repo}\" is already installed. ---")
        choice = input("Overwrite? (y/n): ").lower().strip()
        
        if choice != 'y':
            print("Installation cancelled.")
            return 0
        else:
            print("Removing old version...")
            rmtree(path)
    url = sample_url.format(user=user, repo=repo)
    print(f"Installing \"{user}/{repo}\" from {url}...")
    
    resp = req.get(url)
    if resp.status_code == 200:
        with ZipFile(io.BytesIO(resp.content)) as z:
            z.extractall(path)
        print(f"\"{user}/{repo}\" successfully installed.")
    else:
        print(f'Package \"{user}/{repo}\" not found.')
def exists(user, repo):
    url = sample_url.format(user=user, repo=repo)
    resp = req.get(url)

    if resp.status_code == 200:
        print(f'Package \"{user}/{repo}\" exists.')
    else:
        print(f'Package \"{user}/{repo}\" doesn\'t exist.')
def uninstall(user, repo):
    path = os.path.join('packages', user, repo)
    if os.path.exists(path):
        rmtree(path)
        print(f'"{user}/{repo}" was uninstalled.')
    else:
        print(f'Repository "{user}/{repo}" doesn\'t exist.')
def installed(user, repo):
    os.chdir('packages')
    if os.path.exists(user):
        os.chdir(user)
        if os.path.exists(repo):
            print(f'\"{user}/{repo}\" is installed.')
        else:
            print(f"\"{user}/{repo}\" is not installed.")
    else:
        print(f"\"{user}/{repo}\" is not installed.")

helpMenu = {
    'install':   'Install package from github',
    'exists':    'Shows does package installable',
    'uninstall': 'Uninstall package from pc',
    'installed': 'Shows is package installed',
    'help':      'Shows this menu'
}


if len(sys.argv) >= 2:
    cmd = sys.argv[1].lower().strip()
    if cmd == 'install':
        try:
            install(sys.argv[2], sys.argv[3])
        except Exception as e:
            print(f'Error: {e.__class__.__name__}: {e}')
    elif cmd == 'exists':
        try:
            exists(sys.argv[2], sys.argv[3])
        except Exception as e:
            print(f'Error: {e.__class__.__name__}: {e}')
    elif cmd == 'uninstall':
        try:
            uninstall(sys.argv[2], sys.argv[3])
        except Exception as e:
            print(f'Error: {e.__class__.__name__}: {e}')
    elif cmd == 'help':
        for hcmd, desc in helpMenu.items():
            print(f'{hcmd} : {desc}')
    elif cmd == 'installed':
        try:
            installed(sys.argv[2], sys.argv[3])
        except Exception as e:
            print(f'Error: {e.__class__.__name__}: {str(e)}')
    else:
        print(f"Unknown command: {cmd}")
else:
    print("Usage: brick.exe <cmd> <user> <repo>\nEnter brick.exe help to view available commands")