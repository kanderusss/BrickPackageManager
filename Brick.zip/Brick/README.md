# Brick package manager
# Powered by GitHub

# Usage:
## Installing:
`brick.exe install <user> <repo>`
## Uninstalling:
`brick.exe uninstall <user> <repo>`
## Can be downloaded?:
`brick.exe exists <user> <repo>`
## Is installed?:
`brick.exe installed <user> <repo>`
## Help menu:
`brick.exe help`

# Sample download URL:
`https://github.com/<user>/<repo>/zipball/main`

